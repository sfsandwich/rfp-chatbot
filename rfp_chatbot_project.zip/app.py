
import streamlit as st
import pandas as pd

# Load CSVs
@st.cache_data
def load_rfp(tool):
    if tool == "engagement":
        df = pd.read_csv("Engagement RFP Template - RFP Template.csv")
        questions = df.iloc[2:, 0].dropna().reset_index(drop=True)
    elif tool == "site search":
        df = pd.read_csv("RFP Questions_AI-Powered Site Search LM - Scalability and Redundancy.csv")
        questions = df.iloc[:, 0].dropna().reset_index(drop=True)
    else:
        return pd.DataFrame({"Error": ["Unsupported tool type."]})

    return pd.DataFrame({
        "Question": questions,
        "Self Score (0-4)": "",
        "Experience (0-4)": "",
        "Detailed Answer": "",
        "Attachments": ""
    })

# UI
st.title("RFP Chatbot")
st.write("Tell me what kind of tool you're sourcing and I'll build your custom RFP!")

tool_type = st.text_input("What kind of tool are you sourcing? (e.g. 'engagement', 'site search')")

if tool_type:
    df = load_rfp(tool_type.lower())
    if "Error" in df.columns:
        st.error(df["Error"].iloc[0])
    else:
        st.success(f"Here's your RFP for {tool_type.title()}")
        st.dataframe(df)
        st.download_button("Download RFP as CSV", data=df.to_csv(index=False), file_name=f"{tool_type}_rfp.csv")
